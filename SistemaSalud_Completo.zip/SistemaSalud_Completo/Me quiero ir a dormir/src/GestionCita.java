
/** Interfaz que define operaciones básicas de gestión de citas. */
public interface GestionCita {
    void solicitarCita();
    void cancelarCita();
}
