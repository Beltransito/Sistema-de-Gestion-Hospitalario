
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class SistemaSaludGUI extends JFrame {
    private JTextField nombreField, documentoField, tipoCitaField, fechaCitaField;
    private JButton agendarBtn, cancelarBtn, mostrarBtn;
    private JTextArea areaDatos;
    private ArrayList<Paciente> pacientes;

    // Interfaz principal para gestionar pacientes y sus citas.

    public SistemaSaludGUI() {
        setTitle("Sistema de Gestión de Citas de Salud");
        // Constructor: crea la ventana, layout y botones principales.
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(960, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        pacientes = new ArrayList<>();

        // Sidebar morada
        JPanel sidebar = new JPanel();
        sidebar.setBackground(UITheme.PURPLE);
        sidebar.setPreferredSize(new Dimension(220, 0));
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBorder(new EmptyBorder(24, 18, 24, 18));

        JLabel brand = new JLabel("NexusPrime");
        brand.setAlignmentX(Component.CENTER_ALIGNMENT);
        brand.setForeground(Color.WHITE);
        brand.setFont(UITheme.H2);

        JButton btnInfo = new JButton("Información del programa");
        styleSidebarButton(btnInfo);
        btnInfo.addActionListener(e -> mostrarInfoPrograma());

        JButton btnSalir = new JButton("Salir");
        styleSidebarButton(btnSalir);
        btnSalir.addActionListener(e -> dispose());

        sidebar.add(brand);
        sidebar.add(Box.createVerticalStrut(16));
        sidebar.add(btnInfo);
        sidebar.add(Box.createVerticalGlue());
        sidebar.add(btnSalir);

        // Header con logo pequeño y título
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UITheme.BG_LIGHT);
        header.setBorder(new EmptyBorder(12, 16, 12, 16));
        JLabel smallLogo = new JLabel(loadLogo(22, 22));
        JLabel titulo = new JLabel("Gestión de Citas");
        titulo.setFont(UITheme.H2);
        titulo.setForeground(UITheme.TEXT_DARK);
        JPanel leftHead = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        leftHead.setOpaque(false);
        leftHead.add(smallLogo);
        leftHead.add(titulo);
        header.add(leftHead, BorderLayout.WEST);

        // Formulario
        JPanel panelTop = new JPanel(new GridLayout(2, 4, 10, 8));
        panelTop.setBorder(new EmptyBorder(6, 16, 6, 16));
        panelTop.setBackground(UITheme.BG_LIGHT);

        panelTop.add(styledLabel("Nombre:"));
        nombreField = new JTextField();
        panelTop.add(stylizeField(nombreField));

        panelTop.add(styledLabel("Documento:"));
        documentoField = new JTextField();
        panelTop.add(stylizeField(documentoField));

        panelTop.add(styledLabel("Tipo de Cita:"));
        tipoCitaField = new JTextField();
        panelTop.add(stylizeField(tipoCitaField));

        panelTop.add(styledLabel("Fecha de Cita (DD/MM/AAAA):"));
        fechaCitaField = new JTextField();
        panelTop.add(stylizeField(fechaCitaField));

        // Botones
        JPanel panelBarra = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        panelBarra.setBorder(new EmptyBorder(6, 16, 12, 16));
        panelBarra.setBackground(UITheme.BG_LIGHT);
        agendarBtn = new JButton("Agendar Cita");
        cancelarBtn = new JButton("Cancelar Cita");
        mostrarBtn = new JButton("Mostrar Citas");
        stylePrimaryButton(agendarBtn);
        styleSecondaryButton(cancelarBtn);
        styleSecondaryButton(mostrarBtn);
        panelBarra.add(agendarBtn);
        panelBarra.add(cancelarBtn);
        panelBarra.add(mostrarBtn);

        // Área de datos centrada
        areaDatos = new JTextArea();
        areaDatos.setEditable(false);
        areaDatos.setFont(new Font("Monospaced", Font.PLAIN, 13));

        JPanel content = new JPanel(new BorderLayout(10, 10));
        content.setBackground(UITheme.BG_LIGHT);
        content.add(panelTop, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new BorderLayout(0, 10));
        centerPanel.setOpaque(false);
        centerPanel.add(panelBarra, BorderLayout.NORTH);

        JPanel areaWrapper = new JPanel(new GridBagLayout());
        areaWrapper.setOpaque(false);
        JScrollPane scrollArea = new JScrollPane(areaDatos);
        scrollArea.setPreferredSize(new Dimension(600, 200));
        scrollArea.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.FIELD_LINE),
                new EmptyBorder(10, 10, 10, 10)));
        areaWrapper.add(scrollArea, new GridBagConstraints());
        centerPanel.add(areaWrapper, BorderLayout.CENTER);

        content.add(centerPanel, BorderLayout.CENTER);
        content.setBorder(new EmptyBorder(0, 16, 16, 16));

        add(sidebar, BorderLayout.WEST);
        add(header, BorderLayout.NORTH);
        add(content, BorderLayout.CENTER);

        // Acciones
        agendarBtn.addActionListener(e -> agendarCita());
        cancelarBtn.addActionListener(e -> cancelarCita());
        mostrarBtn.addActionListener(e -> mostrarCitas());
    }

    private void mostrarInfoPrograma() {
        JDialog dlg = new JDialog(this, "Información del programa", true);
        dlg.setSize(520, 360);
        dlg.setLocationRelativeTo(this);
        dlg.setLayout(new BorderLayout());
        dlg.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(UITheme.PURPLE);
        top.setBorder(new EmptyBorder(12, 16, 12, 16));
        JLabel title = new JLabel("Información del programa");
        title.setForeground(Color.WHITE);
        title.setFont(UITheme.H2);
        top.add(title, BorderLayout.WEST);

        JPanel body = new JPanel(new BorderLayout(16, 16));
        body.setBorder(new EmptyBorder(16, 16, 16, 16));
        body.setBackground(UITheme.BG_LIGHT);

        JLabel logo = new JLabel(loadLogo(120, 80));
        logo.setHorizontalAlignment(SwingConstants.CENTER);
        body.add(logo, BorderLayout.WEST);

        JTextArea info = new JTextArea();
        info.setEditable(false);
        info.setOpaque(false);
        info.setFont(UITheme.INPUT);
        info.setText(
                "Sistema de Gestión de Citas de Salud\n" +
                        "Versión:  1.0.0\n" +
                        "Creador:    Kakmanzoo\n" +
                        "Descripción:\n" +
                        "Aplicación de escritorio para agendar, cancelar y consultar\n" +
                        "citas médicas.\n" +
                        "Tecnologías:\n" +
                        "- Java 17\n" +
                        "- Programación orientada a Objetos\n" +
                        "Muchas gracias por usar el programa :)");
        body.add(info, BorderLayout.CENTER);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        footer.setBackground(UITheme.BG_LIGHT);
        JButton cerrar = new JButton("Cerrar");
        styleSecondaryButton(cerrar);
        cerrar.addActionListener(e -> dlg.dispose());
        footer.add(cerrar);

        dlg.add(top, BorderLayout.NORTH);
        dlg.add(body, BorderLayout.CENTER);
        dlg.add(footer, BorderLayout.SOUTH);

        dlg.setVisible(true);
    }

    private JLabel styledLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(UITheme.FORM_LABEL);
        l.setForeground(UITheme.TEXT_DARK);
        return l;
    }

    private JTextField stylizeField(JTextField field) {
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.FIELD_LINE),
                new EmptyBorder(6, 8, 6, 8)));
        field.setFont(UITheme.INPUT);
        field.setForeground(UITheme.TEXT_DARK);
        return field;
    }

    private void stylePrimaryButton(JButton b) {
        b.setFont(UITheme.BUTTON);
        b.setForeground(Color.WHITE);
        b.setBackground(UITheme.PURPLE);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(8, 16, 8, 16));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                b.setBackground(UITheme.PURPLE_DARK);
            }

            public void mouseExited(MouseEvent e) {
                b.setBackground(UITheme.PURPLE);
            }
        });
    }

    private void styleSecondaryButton(JButton b) {
        b.setFont(UITheme.BUTTON);
        b.setForeground(UITheme.PURPLE);
        b.setBackground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.PURPLE),
                new EmptyBorder(8, 16, 8, 16)));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                b.setBackground(new Color(245, 245, 245));
            }

            public void mouseExited(MouseEvent e) {
                b.setBackground(Color.WHITE);
            }
        });
    }

    private void styleSidebarButton(JButton b) {
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        b.setAlignmentX(Component.CENTER_ALIGNMENT);
        b.setFont(UITheme.BUTTON);
        b.setForeground(Color.WHITE);
        b.setBackground(UITheme.PURPLE_DARK);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(8, 12, 8, 12));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                b.setBackground(UITheme.PURPLE);
            }

            public void mouseExited(MouseEvent e) {
                b.setBackground(UITheme.PURPLE_DARK);
            }
        });
    }

    private Icon loadLogo(int w, int h) {
        try {
            ImageIcon icon = new ImageIcon("./src/logo.jpg");
            if (icon.getIconWidth() > 0) {
                Image scaled = icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH);
                return new ImageIcon(scaled);
            }
        } catch (Exception ignored) {
        }
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, w, h);
        g.setColor(UITheme.PURPLE_DARK);
        g.drawRect(1, 1, w - 3, h - 3);
        g.setFont(UITheme.FORM_LABEL);
        g.drawString("LOGO", 8, h / 2);
        g.dispose();
        return new ImageIcon(img);
    }

    // ==== Integración GUI con Paciente ====
    private void agendarCita() {
        // Toma datos del formulario y usa la clase Paciente para agendar.
        String nombre = nombreField.getText().trim();
        String docStr = documentoField.getText().trim();
        if (nombre.isEmpty() || docStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese al menos Nombre y Documento.");
            return;
        }
        int documento;
        try {
            documento = Integer.parseInt(docStr);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Documento debe ser numérico.");
            return;
        }

        Paciente p = null;
        for (Paciente px : pacientes)
            if (px.getDocumento() == documento) {
                p = px;
                break;
            }
        if (p == null) {
            p = new Paciente(nombre, documento);
            pacientes.add(p);
        }

        String tipo = tipoCitaField.getText().trim();
        String fecha = fechaCitaField.getText().trim(); // DD/MM/AAAA

        if (tipo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese el tipo de cita.");
            return;
        }

        if (fecha.isEmpty()) {
            p.solicitarCitaConTipo(tipo);
            areaDatos.setText("Operación: Agendar\nPaciente: " + p.getNombre() + " (" + p.getDocumento()
                    + ")\nFecha solicitada por diálogo.");
        } else {
            p.solicitarCitaConTipoYFecha(tipo, fecha);
            areaDatos.setText("Operación: Agendar\nPaciente: " + p.getNombre() + " (" + p.getDocumento()
                    + ")\nFecha tomada desde GUI: " + fecha);
        }
        limpiarCampos();
    }

    private void cancelarCita() {
        // Busca paciente por documento y solicita cancelar la cita seleccionada.
        String docStr = documentoField.getText().trim();
        if (docStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese el documento para cancelar.");
            return;
        }
        int documento;
        try {
            documento = Integer.parseInt(docStr);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Documento debe ser numérico.");
            return;
        }

        for (Paciente p : pacientes) {
            if (p.getDocumento() == documento) {
                p.cancelarCita();
                areaDatos.setText("Operación: Cancelar\nPaciente: " + p.getNombre() + " (" + p.getDocumento() + ")");
                limpiarCampos();
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "No se encontró paciente con ese documento.");
    }

    private void mostrarCitas() {
        // Muestra información de las citas del paciente en diálogo.
        String docStr = documentoField.getText().trim();
        if (docStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese el documento para mostrar citas.");
            return;
        }
        int documento;
        try {
            documento = Integer.parseInt(docStr);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Documento debe ser numérico.");
            return;
        }

        for (Paciente p : pacientes) {
            if (p.getDocumento() == documento) {
                p.MostrarDatos();
                areaDatos.setText("Operación: Mostrar\nPaciente: " + p.getNombre() + " (" + p.getDocumento()
                        + ")\nDetalle mostrado en diálogo.");
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "No se encontró paciente con ese documento.");
    }

    private void limpiarCampos() {
        nombreField.setText("");
        documentoField.setText("");
        tipoCitaField.setText("");
        fechaCitaField.setText("");
    }
}
