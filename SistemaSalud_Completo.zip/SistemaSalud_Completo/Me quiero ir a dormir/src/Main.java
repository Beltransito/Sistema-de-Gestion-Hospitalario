
import javax.swing.SwingUtilities;

/** Clase de arranque mínima que configura el Look&Feel y muestra la ventana principal. */
public class Main {
    /** Punto de entrada: establece Nimbus (si está) y abre la ventana de inicio. */
    public static void main(String[] args) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignore) {}

        SwingUtilities.invokeLater(() -> new NexusPrime().setVisible(true));
    }
}
