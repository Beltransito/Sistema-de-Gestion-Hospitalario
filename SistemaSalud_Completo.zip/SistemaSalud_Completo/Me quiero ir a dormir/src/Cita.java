
public class Cita {
    private String tipoCita;
    private String fecha;

    // Objeto simple que representa un turno o cita médica.

    public Cita(String tipoCita, String fecha) {
        this.tipoCita = tipoCita;
        this.fecha = fecha;
    }

    public String getTipoCita() { return tipoCita; }
    public String getFecha() { return fecha; }

    @Override
    public String toString() {
        return "Tipo: " + tipoCita + "\nFecha: " + fecha;
    }
}
