
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Paciente extends Datos implements GestionCita {
    private ArrayList<Cita> listaCitas = new ArrayList<>();
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    // Representa a un paciente con una lista de citas y utilidades para gestionarlas.

    public Paciente(String nombre, int documento) { super(nombre, documento); }

    private String validarYNormalizarFecha(String fechaStr) {
        try {
            LocalDate fecha = LocalDate.parse(fechaStr, FMT);
            if (fecha.isBefore(LocalDate.now()))
                throw new IllegalArgumentException("No se puede agendar una cita en el pasado.");
            return fecha.format(FMT);
        } catch (DateTimeParseException ex) {
            throw new IllegalArgumentException("Formato de fecha inválido. Use DD/MM/AAAA");
        }
    }

    private boolean existeDuplicado(String tipoCita, String fechaNormal) {
        for (Cita c : listaCitas) {
            if (c.getTipoCita().equalsIgnoreCase(tipoCita) && c.getFecha().equals(fechaNormal)) return true;
        }
        return false;
    }

    private void agregarCitaSiNoDup(String tipoCita, String fechaNormal) {
        if (existeDuplicado(tipoCita, fechaNormal)) {
            JOptionPane.showMessageDialog(null, "Ya existe una cita de " + tipoCita + " para " + fechaNormal);
            return;
        }
        Cita nueva = new Cita(tipoCita, fechaNormal);
        listaCitas.add(nueva);
        JOptionPane.showMessageDialog(null, "La cita fue agendada:\n" + nueva.toString());
    }


    @Override
    public void solicitarCita() {
        String tipo = JOptionPane.showInputDialog("Tipo de cita:");
        if (tipo == null || tipo.trim().isEmpty()) return;
        String fechaInput = JOptionPane.showInputDialog("Fecha de la cita (DD/MM/AAAA):");
        if (fechaInput == null) return;
        try {
            String fechaNorm = validarYNormalizarFecha(fechaInput.trim());
            agregarCitaSiNoDup(tipo.trim(), fechaNorm);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        }
    }

    public void solicitarCitaConTipo(String tipoDesdeGUI) {
        if (tipoDesdeGUI == null || tipoDesdeGUI.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingrese el tipo de cita.");
            return;
        }
        String fechaInput = JOptionPane.showInputDialog("Fecha de la cita (DD/MM/AAAA): ");
        if (fechaInput == null) return;
        try {
            String fechaNorm = validarYNormalizarFecha(fechaInput.trim());
            agregarCitaSiNoDup(tipoDesdeGUI.trim(), fechaNorm);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        }
    }

    public void solicitarCitaConTipoYFecha(String tipoDesdeGUI, String fechaDesdeGUI) {
        if (tipoDesdeGUI == null || tipoDesdeGUI.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingrese el tipo de cita.");
            return;
        }
        if (fechaDesdeGUI == null || fechaDesdeGUI.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Ingrese la fecha de la cita (DD/MM/AAAA).");
            return;
        }
        try {
            String fechaNorm = validarYNormalizarFecha(fechaDesdeGUI.trim());
            agregarCitaSiNoDup(tipoDesdeGUI.trim(), fechaNorm);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        }
    }

    @Override
    public void cancelarCita() {
        if (listaCitas.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No tienes citas para cancelar.");
            return;
        }
        StringBuilder lista = new StringBuilder("Seleccione la cita a cancelar:\n");
        for (int i = 0; i < listaCitas.size(); i++) {
            lista.append((i + 1)).append(". ").append(listaCitas.get(i).toString()).append("\n");
        }
        String idxStr = JOptionPane.showInputDialog(lista.toString());
        if (idxStr == null) return;

        try {
            int idx = Integer.parseInt(idxStr) - 1;
            if (idx >= 0 && idx < listaCitas.size()) {
                Cita cancelada = listaCitas.remove(idx);
                JOptionPane.showMessageDialog(null, "Cita cancelada:\n" + cancelada.toString());
            } else JOptionPane.showMessageDialog(null, "Número inválido.");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Entrada inválida.");
        }
    }

    @Override
    public void MostrarDatos() {
        super.MostrarDatos();
        if (listaCitas.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay citas agendadas.");
            return;
        }
        StringBuilder sb = new StringBuilder("Citas registradas:\n");
        for (Cita c : listaCitas) sb.append("- ").append(c.toString()).append("\n");
        JOptionPane.showMessageDialog(null, sb.toString());
    }
}
