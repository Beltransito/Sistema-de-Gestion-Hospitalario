
import javax.swing.JOptionPane;

/** Clase base simple que contiene datos básicos de una persona/paciente. */
public class Datos {
    private String nombre;
    private int documento;

    public Datos(String nombre, int documento) {
        this.nombre = nombre;
        this.documento = documento;
    }

    public String getNombre() { return nombre; }
    public int getDocumento() { return documento; }

    // Muestra un diálogo con nombre y documento.
    public void MostrarDatos() {
        JOptionPane.showMessageDialog(null, "Nombre: " + nombre + "\nDocumento: " + documento);
    }
}
