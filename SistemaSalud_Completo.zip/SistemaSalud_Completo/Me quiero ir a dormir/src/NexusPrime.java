
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;

public class NexusPrime extends JFrame {
    // Ventana de inicio de sesión con campos de usuario/clave y control simple de usuarios.
    private PlaceholderTextField txtUsuario;
    private PlaceholderPasswordField txtContrasena;

    private JButton btnIngresar;
    private JCheckBox chkMostrar;
    private JLabel logoLabel;

    private final Map<String, String> users = new HashMap<>();

    public NexusPrime() {
        super("NexusPrime - Inicio de Sesión");
        // Constructor: inicializa la UI y los usuarios de ejemplo.
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 560);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        seedUsers();

        JPanel left = buildLeftPane();
        JPanel right = buildRightPane();

        add(left, BorderLayout.CENTER);
        add(right, BorderLayout.EAST);
    }

    private void seedUsers() {
        users.put("admin", "1234");
        users.put("recepcion", "abcd");
        users.put("medico", "med2025");
    }

    // Método de utilidad para precargar usuarios de ejemplo (solo demo).

    private JPanel buildLeftPane() {
        JPanel left = new JPanel(new BorderLayout());
        left.setBackground(UITheme.BG_LIGHT);
        left.setBorder(new EmptyBorder(20, 24, 20, 36));

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        top.setOpaque(false);
        JLabel miniLogo = new JLabel(loadLogo(18, 18));
        JLabel miniText = new JLabel("LOGO");
        miniText.setFont(UITheme.SMALL);
        miniText.setForeground(UITheme.TEXT_MUTED);
        top.add(miniLogo);
        top.add(miniText);

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints gc = new GridBagConstraints();
        gc.gridx = 0; gc.gridy = 0;
        gc.anchor = GridBagConstraints.WEST;

        JLabel h1 = new JLabel("INICIAR SESIÓN");
        h1.setFont(UITheme.H1);
        h1.setForeground(UITheme.TEXT_DARK);

        JLabel lUser = new JLabel("USUARIO");
        lUser.setFont(UITheme.FORM_LABEL);
        lUser.setForeground(UITheme.TEXT_DARK);

        txtUsuario = new PlaceholderTextField("Digite tu usuario");
        stylizeUnderlineField(txtUsuario);

        JLabel lPass = new JLabel("CONTRASEÑA");
        lPass.setFont(UITheme.FORM_LABEL);
        lPass.setForeground(UITheme.TEXT_DARK);

        txtContrasena = new PlaceholderPasswordField("Digite tu contraseña");
        stylizeUnderlineField(txtContrasena);

        chkMostrar = new JCheckBox("Mostrar contraseña");
        chkMostrar.setOpaque(false);
        chkMostrar.setFont(UITheme.SMALL);
        chkMostrar.setForeground(UITheme.TEXT_MUTED);
        chkMostrar.addActionListener(e -> {
            if (chkMostrar.isSelected()) txtContrasena.setEchoChar((char) 0);
            else txtContrasena.setEchoChar('\u2022');
        });

        btnIngresar = new JButton("INICIAR");
        stylePrimaryButton(btnIngresar);
        btnIngresar.addActionListener(this::onLogin);
        getRootPane().setDefaultButton(btnIngresar);

        // Layout
        gc.gridwidth = 2; gc.insets = new Insets(4, 0, 24, 0);
        form.add(h1, gc);
        gc.gridy++; gc.insets = new Insets(0, 0, 6, 0);
        form.add(lUser, gc);
        gc.gridy++; gc.fill = GridBagConstraints.HORIZONTAL; gc.insets = new Insets(0, 0, 16, 0);
        setFieldHeight(txtUsuario, 34); form.add(txtUsuario, gc);
        gc.gridy++; gc.fill = GridBagConstraints.NONE; gc.insets = new Insets(0, 0, 6, 0);
        form.add(lPass, gc);
        gc.gridy++; gc.fill = GridBagConstraints.HORIZONTAL; gc.insets = new Insets(0, 0, 6, 0);
        setFieldHeight(txtContrasena, 34); form.add(txtContrasena, gc);
        gc.gridy++; gc.fill = GridBagConstraints.NONE; gc.insets = new Insets(0, 0, 22, 0);
        form.add(chkMostrar, gc);
        gc.gridy++; gc.gridwidth = 1; gc.insets = new Insets(0, 0, 0, 0);
        form.add(btnIngresar, gc);

        left.add(top, BorderLayout.NORTH);
        left.add(form, BorderLayout.CENTER);
        return left;
    }

    private JPanel buildRightPane() {
        JPanel right = new JPanel();
        right.setPreferredSize(new Dimension(360, 560));
        right.setBackground(UITheme.PURPLE);
        right.setLayout(new BoxLayout(right, BoxLayout.Y_AXIS));
        right.setBorder(new EmptyBorder(40, 20, 40, 20));

        logoLabel = new JLabel(loadLogo(260, 180));
        logoLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel brand = new JLabel("NexusPrime");
        brand.setForeground(Color.WHITE);
        brand.setFont(UITheme.H1);
        brand.setAlignmentX(Component.CENTER_ALIGNMENT);

        right.add(Box.createVerticalGlue());
        right.add(logoLabel);
        right.add(Box.createVerticalStrut(30));
        right.add(brand);
        right.add(Box.createVerticalGlue());

        return right;
    }

    private Icon loadLogo(int w, int h) {
        try {
            ImageIcon icon = new ImageIcon("./src/logo.jpg");
            if (icon.getIconWidth() > 0) {
                Image scaled = icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH);
                return new ImageIcon(scaled);
            }
        } catch (Exception ignored) {}
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setColor(Color.WHITE); g.fillRect(0, 0, w, h);
        g.setColor(UITheme.PURPLE_DARK);
        g.drawRect(1, 1, w-3, h-3);
        g.setFont(UITheme.FORM_LABEL);
        g.drawString("LOGO", 8, h/2);
        g.dispose();
        return new ImageIcon(img);
    }

    private void stylizeUnderlineField(JTextField field) {
        field.setBorder(new MatteBorder(0, 0, 2, 0, UITheme.FIELD_LINE));
        field.setFont(UITheme.INPUT);
        field.setForeground(UITheme.TEXT_DARK);
        field.setCaretColor(UITheme.TEXT_DARK);
        field.setOpaque(false);
        field.setMargin(new Insets(4, 2, 4, 2));
    }

    private void stylePrimaryButton(JButton b) {
        b.setFont(UITheme.BUTTON);
        b.setForeground(Color.WHITE);
        b.setBackground(UITheme.PURPLE);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(10, 22, 10, 22));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { b.setBackground(UITheme.PURPLE_DARK); }
            public void mouseExited(MouseEvent e) { b.setBackground(UITheme.PURPLE); }
        });
    }

    private void setFieldHeight(JTextField field, int h) {
        Dimension d = field.getPreferredSize();
        d.height = h;
        field.setPreferredSize(d);
        field.setMinimumSize(d);
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, h));
    }

    private void onLogin(ActionEvent e) {
        String user = txtUsuario.getText().trim();
        String pass = new String(txtContrasena.getPassword());

        if (user.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingresa usuario y contraseña.", "Datos incompletos", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String stored = users.get(user);
        if (stored == null) {
            JOptionPane.showMessageDialog(this, "Usuario no existe.", "Credenciales inválidas", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!stored.equals(pass)) {
            JOptionPane.showMessageDialog(this, "Contraseña incorrecta.", "Credenciales inválidas", JOptionPane.ERROR_MESSAGE);
            return;
        }
        // Inicio exitoso: abrir GUI principal del sistema y cerrar esta ventana.
        new SistemaSaludGUI().setVisible(true);
        dispose();
    }

    public static void main(String[] args) {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignore) {}
        SwingUtilities.invokeLater(() -> new NexusPrime().setVisible(true));
    }
}

class PlaceholderTextField extends JTextField {
    private String placeholder;
    public PlaceholderTextField(String placeholder) { super(); this.placeholder = placeholder; }
    @Override protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (getText().isEmpty() && !isFocusOwner()) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setColor(UITheme.TEXT_MUTED);
            g2.setFont(UITheme.PLACEHOLDER);
            Insets in = getInsets();
            g2.drawString(placeholder, in.left + 2, getHeight()/2 + getFont().getSize()/2 - 2);
            g2.dispose();
        }
    }
}

class PlaceholderPasswordField extends JPasswordField {
    private String placeholder;
    public PlaceholderPasswordField(String placeholder) { super(); this.placeholder = placeholder; setEchoChar('\u2022'); }
    @Override protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (getPassword().length == 0 && !isFocusOwner()) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setColor(UITheme.TEXT_MUTED);
            g2.setFont(UITheme.PLACEHOLDER);
            Insets in = getInsets();
            g2.drawString(placeholder, in.left + 2, getHeight()/2 + getFont().getSize()/2 - 2);
            g2.dispose();
        }
    }
}
