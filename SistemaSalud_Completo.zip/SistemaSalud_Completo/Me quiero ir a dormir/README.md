
# Sistema de Gestión de Citas de Salud (Java Swing)

Aplicación de escritorio en **Java (Swing)** con **login**, **gestión de citas** y diseño visual consistente.

## Requisitos
- JDK 17+
- VS Code + Extension Pack for Java

## Estructura
Coloca todos los `.java` y `logo.png` en la misma carpeta (sin packages). Ejecuta `Main.java`.

## Login
Edita `seedUsers()` en `NexusPrime.java` para cambiar usuarios.

## Citas
- Desde GUI: usa `tipo` y `fecha` si están; si `fecha` va vacía, se pide por diálogo.
- Cancelar: selecciona cuál eliminar.
- Mostrar: despliega todas las citas del paciente.

## Cambiar fuente
En `UITheme.java` cambia `"SansSerif"` por `"Lucida Fax"` en las fuentes.
